<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
    <link rel="stylesheet" href="<?= base_url('assets/css/style.css'); ?>">
</head>
<body>

<!-- NAVBAR -->
<div class="navbar">
    <div class="logo"></div>
    <div class="btn-group">
        <a href="#" class="btn-login">Login</a>
        <a href="#" class="btn-register">Register</a>
    </div>
</div>
