
<footer class="footer">
    <div class="medsos">
        <i class="icon">IG</i>
        <i class="icon">FB</i>
        <i class="icon">WA</i>
    </div>

    <p>© 2025 Geize Company. All Right Reserved</p>
</footer>

</body>
</html>
